// Parallax
const scene = $('.parallax-wrapper_second').get(0);
const parallaxInstance = new Parallax(scene);
